import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from audit_courseware import audit_project
from pack_single_html import build_single_html


class CoursewareSkillToolsTests(unittest.TestCase):
    def make_site(self, base: Path, *, lines=None, voice=None, html=None, asset=True, lab=False):
        (base/'assets').mkdir(exist_ok=True)
        (base/'audio'/'voice').mkdir(parents=True, exist_ok=True)
        if asset:
            (base/'assets'/'hero.webp').write_bytes(b'RIFF1234WEBPVP8 ')
        (base/'audio'/'voice'/'one.mp3').write_bytes(b'ID3'+b'0'*20)
        scenes = [{'id': 'home', 'nav':'首页', 'img': 'assets/hero.webp', 'dialog': lines or [['S','你好']]}]
        if lab:
            scenes.append({'id': 'lab', 'nav': '模型实验室', 'img': 'assets/hero.webp',
                           'dialog': [['Z','欢迎进入模型实验室']]})
        content={'scenes':scenes, 'voiceMap':voice if voice is not None else {'S|你好':'audio/voice/one.mp3'}}
        (base/'data.js').write_text('const CONTENT='+json.dumps(content,ensure_ascii=False)+';', encoding='utf8')
        (base/'style.css').write_text('body{background-image:url("assets/hero.webp")}',encoding='utf8')
        (base/'app.js').write_text('window.READY=true;',encoding='utf8')
        (base/'index.html').write_text(html or '''<!doctype html><html><head><link rel="stylesheet" href="style.css" /></head>
<body><h1>欢迎进入故事</h1><script src="data.js"></script><script src="app.js"></script></body></html>''',encoding='utf8')

    def test_red_missing_voice_detected(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d)
            self.make_site(base, voice={})
            issues=audit_project(base, require_voice=True)
            self.assertTrue(any(i['code']=='MISSING_VOICE' for i in issues), issues)

    def test_missing_asset_detected(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d)
            self.make_site(base, asset=False)
            issues=audit_project(base, require_voice=True)
            self.assertTrue(any(i['code']=='MISSING_ASSET' for i in issues), issues)

    def test_visible_authoring_note_and_bad_tag_detected(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d)
            self.make_site(base, html='''<html><body><p>本版优化配音，开发调试提示</p><script<script src="app.js"></script></body></html>''')
            issues=audit_project(base)
            self.assertTrue(any(i['code']=='AUTHORING_NOTE_VISIBLE' for i in issues), issues)
            self.assertTrue(any(i['code']=='MALFORMED_SCRIPT' for i in issues), issues)

    def test_laboratory_requires_live_controls(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d)
            self.make_site(base, lab=True)
            issues=audit_project(base, require_lab=True)
            self.assertTrue(any(i['code']=='LAB_MISSING_CONTROL' for i in issues), issues)

    def test_good_minimal_project_has_no_errors(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d)
            self.make_site(base)
            self.assertEqual(audit_project(base, require_voice=True), [])

    def test_pack_emits_self_contained_data_uris(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d)
            self.make_site(base)
            out=base/'standalone.html'
            build_single_html(base,out)
            s=out.read_text(encoding='utf8')
            self.assertIn('data:image/webp;base64,', s)
            self.assertIn('data:audio/mpeg;base64,', s)
            self.assertNotIn('src="data.js"', s)
            self.assertNotIn('href="style.css"', s)
            self.assertNotIn('src="app.js"', s)
            self.assertIn('window.READY=true', s)


if __name__=='__main__': unittest.main()
