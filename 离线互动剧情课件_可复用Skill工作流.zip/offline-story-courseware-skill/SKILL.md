---
name: building-offline-story-courseware
description: Use when converting a teaching brief, Word script, or story into an offline, multi-scene interactive website with voice acting, comic/story modes, business decisions, or adjustable educational models; also use when fixing such a website after complaints about poster layout, mechanical voices, missing audio, inconsistent devices, or broken interactions.
---

# Building Offline Story Courseware｜离线互动剧情课件

**目标：**把剧本型教学内容交付为可用于课堂/答辩的离线作品，而不只是“能打开的网页”。**核心原则：内容忠于源材料、视觉像作品、语音可跨设备复现、模型真能操作、每次修改都做回归测试。**

## 何时使用

- 从教学文件/对话脚本制作逐幕互动剧情、橙光/漫画双模式、经营指标和教学决策。
- 在已有作品上改封面、人物配音、结算页、实时经济学图表，同时保留用户已认可部分。
- 面临离线演示、Windows/白板/手机兼容性或需要“单 HTML + 完整素材 ZIP”的交付。

## 严格工作流（按顺序）

1. **提取原始需求 → 建立追踪矩阵。**读取用户给的文件，逐条提取幕次、角色、原话、时间线、KPI、决策、公式与媒介需求；标记来自源材料还是新增设计，不擅自修改事实。见 [需求模板](templates/project-brief.json)。
2. **冻结已认可基线。**备份上一版，记录用户明确说“这部分没问题”的模块。每次迭代只改变目标模块；保留版本号和变更清单。不能用视觉重做换取其他功能退化。
3. **确定信息架构。**剧情独立按幕推进（没有正文长滚动）；每幕固定一条当前对白、CG/漫画可切换、右侧数据或情境卡、自然转场。独立可调模型应成为**单独场景**，不是只藏在弹窗中。
4. **先设计开头与结尾，再做页面。**开头采用完整原画、可读标题、故事主题、可见的「开始故事」按钮；结尾采用通关结算、进度/成就、剧情回顾与模型入口。**学生前端只放作品内容和必要玩法提示**，禁止出现「本版优化」「A/B方向」「修音方案」「制作说明」等开发沟通文字。
5. **音频按“先试听，后批量，最后内嵌”验收。**角色声线来自真正不同的可用自然语音/授权录音，不靠反复变调模仿真人；先生成女主、男主、旁白试听并得到认可，再合成每句。必须有每句音频清单、长度/文件检查、映射校验；网页播放预生成的 MP3，**不得默认依赖设备系统 TTS**。具体故障分支见 [声音与离线标准](references/audio-offline.md)。
6. **建真正实时的教学模型。**独立页面提供参数滑块、情景预设、可视化曲线、交点和数字；滑动即重新计算并更新图形/解读。区分短期价格黏性与长期产出归位，明确模型假设。见 [模型验收](references/model-lab.md)。
7. **用脚本预检，然后用浏览器走全流程。**静态审计：`python scripts/audit_courseware.py <源码目录> --require-voice --require-lab`；打包：`python scripts/pack_single_html.py <源码目录> <输出.html>`。浏览器实际检查封面、每幕、两种模式、决策、滑块、通关、自动播放和无滚动。可运行 `python scripts/browser_smoke.py <单文件.html> --expected-scenes 10 --require-lab` 做基础联通测试，并在桌面/投影/手机留截图。具体清单见 [交付门槛](references/quality-gates.md)。
8. **只发布已验证的状态。**输出单文件 HTML、可编辑素材 ZIP、更新记录及测试结果。区分“代码已写好”“模拟测试通过”“在线生成成功”“人工听感认可”；合成未成功时，不得宣称“真人配音完成”。

## 三个不可妥协的停机点

- **音色不符合要求 / 服务返回 403：**停在试听阶段，更换**可用的**合成服务或询问所缺授权；不拿旧机械音改调后伪称真人，更不把联网系统 TTS 称为离线可复现。
- **音频映射不完整：**补齐所有对白，禁止带着无声台词发布。幕数变化后必须重新统计。
- **封面错位 / 交互未测：**不做“终极版”宣称；回到最新验证过的基线逐项修正。

> 此 Skill 的来源与已知错误模式见 [案例复盘](references/case-study.md)。工具是静态检查与打包助手，**不代替人工试听、公式校验和真浏览器验证**。
