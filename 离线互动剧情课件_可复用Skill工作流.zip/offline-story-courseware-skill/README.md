# 离线互动剧情课件 Skill

这是一份可复用的 Agent Skill：`building-offline-story-courseware`。它把一次“教学 Word → 游戏化九幕 → 海报开场 → 漫画/橙光 → 经营决策 → 游戏通关 → 10 幕独立 AD–AS 模型页 → 自然配音和离线交付”的多轮制作经历，转化为可检索、可执行、有测试门槛的工作流程。

## 安装或复用

把整个 `offline-story-courseware-skill` 文件夹放入支持 Agent Skills 的环境所用的技能目录中，例如支持 `~/.agents/skills/` 的代理工具。**这份 ZIP 是技能源码包，下载并不等于已自动安装到当前 ChatGPT 账户。**

不支持加载 Agent Skills 的环境，也可把 `SKILL.md` 作为下一次协作的工作流规范交给助手，同时参考 `references/` 和 `templates/`。

## 调用示例

> 使用 `building-offline-story-courseware` Skill，把这份教学剧本做成可以离线展示的互动剧情网站。要求固定真人感男女声、独立实时模型页、电影封面、无开发说明泄漏、手机及投影测试。

## 文件

- `SKILL.md`：技能入口与不可妥协的工作顺序
- `references/case-study.md`：前次完整过程的成功经验、退化问题和真实数据
- `references/audio-offline.md`：预录音、自然配音试听、服务故障与离线要求
- `references/model-lab.md`：独立实时模型验收
- `references/quality-gates.md`：发布前检查表
- `templates/*.json`：需求映射及交付验收状态模板
- `scripts/audit_courseware.py`：现有 `CONTENT` 数据结构的静态完整性审计
- `scripts/pack_single_html.py`：可移植的单文件 HTML 素材内嵌脚本
- `scripts/browser_smoke.py`：Playwright 桌面／投影／手机交互冒烟测试（需单独安装 Playwright 和 Chromium）
- `tests/test_workflow.py`：脚本回归测试
- `tests/evaluation_scenarios.md`：未来代理的行为验收情境

## 自检

```bash
cd offline-story-courseware-skill
python -m unittest discover -s tests -v
```

**局限：**自带脚本适配历史项目使用的 `const CONTENT = {...};`、`index.html`、`style.css`、`app.js` 结构。对于 React/Vue/Svelte 等项目保留工作流，但需要替换静态审计和打包实现。脚本不能创造高质量音频；真正的自然配音依赖可用的合成服务或授权录音，必须亲耳试听。
