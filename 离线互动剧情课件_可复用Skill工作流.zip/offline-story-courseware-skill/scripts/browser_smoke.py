#!/usr/bin/env python3
"""Basic Playwright interaction smoke test for the CONTENT-based story site.

Requires: pip install playwright; a Chromium browser must be installed or pass
--chromium /path/to/chromium. This checks interactive wiring and overflow, NOT
voice quality nor the correctness of the economic model's equations.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import sys


def smoke(path: Path, viewports: list[tuple[int, int]], expected_scenes: int = 0,
          lab: bool = False, chromium: str | None = None) -> list[str]:
    from playwright.sync_api import sync_playwright
    errors = []
    html_source = path.read_text(encoding='utf-8-sig')
    with sync_playwright() as p:
        kwargs = {'headless': True, 'args': ['--no-sandbox', '--disable-dev-shm-usage']}
        if chromium:
            kwargs['executable_path'] = chromium
        browser = p.chromium.launch(**kwargs)
        for w, h in viewports:
            label = f'{w}x{h}'
            page = browser.new_page(viewport={'width': w, 'height': h})
            page.on('pageerror', lambda exc, label=label: errors.append(f'[{label}] JavaScript: {exc}'))
            try:
                # Sandboxed Chromium installations may block file:// navigation.
                # Load the already-inlined single HTML as document content.
                # External assets will NOT resolve in this mode: test the packed HTML.
                page.set_content(html_source, wait_until='domcontentloaded', timeout=60000)
                page.locator('#entryOverlay').wait_for(timeout=10000)
                if not page.locator('#entryPlay').is_visible():
                    errors.append(f'[{label}] start button not visible on cover')
                bounds = page.locator('#entryPlay').bounding_box()
                if bounds and (bounds['y'] + bounds['height'] > h or bounds['x'] + bounds['width'] > w):
                    errors.append(f'[{label}] start button is outside the viewport')
                page.locator('#entryPlay').click(timeout=10000)
                page.locator('#entryOverlay').wait_for(state='hidden', timeout=10000)
                if page.locator('#app').count() != 1:
                    errors.append(f'[{label}] site did not render app')
                # Main application should stay within viewport. Scrollable
                # overlays are checked separately in manual QA.
                metrics = page.evaluate('''() => ({
                    cw:document.documentElement.scrollWidth,
                    ch:document.documentElement.scrollHeight,
                    w:window.innerWidth,
                    h:window.innerHeight
                })''')
                if metrics['cw'] > metrics['w'] + 3:
                    errors.append(f'[{label}] horizontal overflow by {metrics["cw"]-metrics["w"]}px')
                if metrics['ch'] > metrics['h'] + 5:
                    errors.append(f'[{label}] vertical document overflow by {metrics["ch"]-metrics["h"]}px')
                page.locator('#menuBtn').click(timeout=10000)
                picker = page.locator('#scenePicker button[data-scene]')
                if expected_scenes and picker.count() != expected_scenes:
                    errors.append(f'[{label}] scene count = {picker.count()}, expected {expected_scenes}')
                if lab:
                    lab_idx = picker.count() - 1
                    if lab_idx < 0:
                        errors.append(f'[{label}] no scenes to navigate')
                    else:
                        picker.nth(lab_idx).click(timeout=10000)
                        page.locator('#labScreen').wait_for(state='visible', timeout=12000)
                        page.locator('#shockSliderPage').fill('0', timeout=10000)
                        before = page.locator('#resultYPage').inner_text()
                        page.locator('#shockSliderPage').fill('80', timeout=10000)
                        after = page.locator('#resultYPage').inner_text()
                        if before == after:
                            errors.append(f'[{label}] demand shock slider did not change output')
                        if not page.locator('#adaSvgPage path').count():
                            errors.append(f'[{label}] AD-AS SVG not rendered')
                else:
                    page.locator('#closeMenu').click(timeout=10000)
            except Exception as exc:
                errors.append(f'[{label}] test exception: {str(exc)[:300]}')
            finally:
                page.close()
        browser.close()
    return errors


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description='Run browser smoke checks on a story-courseware HTML')
    ap.add_argument('html', type=Path, help='Packed single HTML; source index.html alone is not enough')
    ap.add_argument('--expected-scenes', type=int, default=0)
    ap.add_argument('--require-lab', action='store_true')
    ap.add_argument('--chromium', help='Path to local Chromium executable')
    args = ap.parse_args(argv)
    viewports = [(1366, 768), (1280, 720), (390, 844)]
    failures = smoke(args.html, viewports, args.expected_scenes, args.require_lab, args.chromium)
    if failures:
        print('FAIL: browser smoke')
        print('\n'.join(' - '+x for x in failures))
        return 1
    print('PASS: desktop/projector/mobile browser smoke (still need audio listening + deep QA)')
    return 0


if __name__ == '__main__':
    sys.exit(main())
