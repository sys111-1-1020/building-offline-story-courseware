#!/usr/bin/env python3
"""Turn a self-contained source site into one HTML file with embedded media.

Designed for the CONTENT-based source layout: index.html, style.css, data.js,
app.js, assets/, audio/. No external runtime services.
"""
from __future__ import annotations
import argparse
import base64
import mimetypes
from pathlib import Path
import sys


def build_single_html(root: Path, dest: Path):
    root, dest = Path(root), Path(dest)
    html = (root / 'index.html').read_text(encoding='utf-8-sig')
    tokens = {
        '<link rel="stylesheet" href="style.css" />': '<style>\n'+(root/'style.css').read_text(encoding='utf-8-sig')+'\n</style>',
        '<script src="data.js"></script>': '<script>\n'+(root/'data.js').read_text(encoding='utf-8-sig')+'\n</script>',
        '<script src="app.js"></script>': '<script>\n'+(root/'app.js').read_text(encoding='utf-8-sig')+'\n</script>',
    }
    for old, new in tokens.items():
        if html.count(old) != 1:
            raise ValueError(f'Missing or duplicated expected source reference: {old}')
        html = html.replace(old, new)

    source_media = []
    for folder in ('assets', 'audio'):
        if (root/folder).exists():
            source_media += [p for p in (root/folder).rglob('*') if p.is_file()]
    # Sorting by longest relative path prevents accidental substring collisions.
    source_media.sort(key=lambda p: len(p.relative_to(root).as_posix()), reverse=True)
    for p in source_media:
        rel = p.relative_to(root).as_posix()
        if rel not in html:
            continue
        mime = mimetypes.guess_type(rel)[0] or 'application/octet-stream'
        uri = f'data:{mime};base64,{base64.b64encode(p.read_bytes()).decode("ascii")}'
        html = html.replace(rel, uri)
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(html, encoding='utf-8')
    return dest


def main(argv=None):
    ap = argparse.ArgumentParser(description='Build standalone HTML with embedded assets and audio')
    ap.add_argument('source_folder', type=Path)
    ap.add_argument('output_html', type=Path)
    args = ap.parse_args(argv)
    try:
        out=build_single_html(args.source_folder, args.output_html)
    except (OSError, ValueError) as e:
        print(f'FAIL: {e}', file=sys.stderr)
        return 1
    print(f'Wrote {out} ({out.stat().st_size / 1024 / 1024:.1f} MiB)')
    return 0


if __name__ == '__main__':
    sys.exit(main())
