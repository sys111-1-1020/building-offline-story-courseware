#!/usr/bin/env python3
"""Preflight checks for the CONTENT-based offline story-courseware project layout.

Uses the Python standard library only. It catches common *static* errors; it
cannot replace browser interaction or voice listening tests.
"""
from __future__ import annotations

import argparse
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import sys


class VisibleTextParser(HTMLParser):
    """Collect HTML text nodes that a reader may see; exclude scripts/styles."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.hidden_stack = []
        self.chunks = []

    def handle_starttag(self, tag, attrs):
        self.hidden_stack.append(tag in {'script', 'style', 'title', 'noscript', 'template'} or any(self.hidden_stack))

    def handle_endtag(self, tag):
        if self.hidden_stack:
            self.hidden_stack.pop()

    def handle_data(self, data):
        if not any(self.hidden_stack) and data.strip():
            self.chunks.append(data)


def parse_content(data_js: str) -> dict:
    match = re.search(r'\bconst\s+CONTENT\s*=\s*(\{[\s\S]*\})\s*;?\s*$', data_js)
    if not match:
        raise ValueError("Expected data.js to assign JSON to 'const CONTENT = ...;'")
    return json.loads(match.group(1))


def audit_project(root: Path, *, require_voice: bool = False, require_lab: bool = False) -> list[dict[str, str]]:
    root = Path(root)
    issues: list[dict[str, str]] = []

    def issue(code: str, detail: str):
        issues.append({'code': code, 'detail': detail})

    for name in ('index.html', 'style.css', 'app.js', 'data.js'):
        if not (root / name).is_file():
            issue('MISSING_FILE', name)
    if any(x['code'] == 'MISSING_FILE' for x in issues):
        return issues

    html = (root / 'index.html').read_text(encoding='utf-8-sig')
    app = (root / 'app.js').read_text(encoding='utf-8-sig')
    data = (root / 'data.js').read_text(encoding='utf-8-sig')
    if '<script<script' in html or '</script></script>' in html:
        issue('MALFORMED_SCRIPT', 'Malformed or duplicated script tag')

    parser = VisibleTextParser()
    parser.feed(html)
    visible = ' '.join(parser.chunks)
    bad_notes = re.findall(r'本版(?:优化|升级|修复)|开发调试|代码调试|前端不要|按用户要求|制作说明|本次改动|音色继续拉开|模型页再做', visible)
    if bad_notes:
        issue('AUTHORING_NOTE_VISIBLE', ', '.join(sorted(set(bad_notes))))

    if re.search(r'<script\b[^>]+\bsrc\s*=\s*["\']https?://', html, re.I) or re.search(r'<link\b[^>]+\bhref\s*=\s*["\']https?://', html, re.I):
        issue('RUNTIME_NETWORK_DEPENDENCY', 'Externally hosted script or stylesheet in index.html')

    try:
        content = parse_content(data)
    except (ValueError, json.JSONDecodeError) as e:
        issue('BAD_CONTENT_DATA', str(e))
        return issues

    scenes = content.get('scenes', [])
    voice_map = content.get('voiceMap', {})
    if not isinstance(scenes, list) or not scenes:
        issue('EMPTY_SCENES', 'data.js must contain a non-empty scenes list')
        return issues
    if not isinstance(voice_map, dict):
        issue('BAD_VOICE_MAP', 'voiceMap must be a dictionary')
        return issues
    used_paths = set()
    for scene in scenes:
        sid = scene.get('id', '?')
        for field in ('img',):
            asset = scene.get(field)
            if asset and isinstance(asset, str):
                used_paths.add(asset)
        for asset in scene.get('panels', []) or []:
            if isinstance(asset, str):
                used_paths.add(asset)
        for i, line in enumerate(scene.get('dialog', [])):
            if not isinstance(line, (list, tuple)) or len(line) < 2:
                issue('BAD_DIALOGUE', f'{sid}: dialogue {i+1} not [speaker, text]')
                continue
            speaker, words = line[:2]
            key = f'{speaker}|{words}'
            if require_voice and not voice_map.get(key):
                issue('MISSING_VOICE', f'{sid} line {i+1}: {speaker}: {str(words)[:35]}')
    for key, src in voice_map.items():
        if isinstance(src, str):
            used_paths.add(src)
    for rel in sorted(used_paths):
        if rel.startswith(('data:', 'http://', 'https://')):
            if rel.startswith(('http:', 'https:')):
                issue('EXTERNAL_MEDIA', f'Media is remote: {rel[:75]}')
            continue
        p = root / rel
        if not p.is_file() or not p.resolve().is_relative_to(root.resolve()):
            issue('MISSING_ASSET', rel)

    has_lab = any(s.get('id') == 'lab' for s in scenes)
    if require_lab and not has_lab:
        issue('LAB_MISSING_SCENE', 'No dedicated lab scene (id=lab)')
    if require_lab or has_lab:
        for selector in ('id="labScreen"', 'id="shockSliderPage"', 'id="flexSliderPage"', 'id="adaSvgPage"', 'data-preset-page'):
            if selector not in html:
                issue('LAB_MISSING_CONTROL', selector)
        if 'renderModelPage' not in app or "'input'" not in app:
            issue('LAB_MISSING_REACTIVITY', 'Expected reactive range-slider change handlers and model redraw')
    return issues


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description='Audit a CONTENT-based offline story-courseware source folder')
    ap.add_argument('source_folder', type=Path)
    ap.add_argument('--require-voice', action='store_true', help='Fail on every unmapped dialogue line')
    ap.add_argument('--require-lab', action='store_true', help='Require a separate live AD-AS lab scene')
    args = ap.parse_args(argv)
    issues = audit_project(args.source_folder, require_voice=args.require_voice, require_lab=args.require_lab)
    if issues:
        print(f'FAIL: {len(issues)} issue(s)')
        for i in issues:
            print(f" - [{i['code']}] {i['detail']}")
        return 1
    print('PASS: no static issues found (browser + audio listening checks still required)')
    return 0


if __name__ == '__main__':
    sys.exit(main())
