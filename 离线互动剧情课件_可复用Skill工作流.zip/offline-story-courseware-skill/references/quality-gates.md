# 每个版本交付前的质量门槛

## A. 文档与内容

- [ ] 已回读原始 Word/PDF/对话脚本；逐幕核对原话和数值，不造剧情事实
- [ ] 所有修改列出「保持不变／本次修改／新增」三部分
- [ ] 经济学概念与图表对应真实计算；长期均衡和短期价格黏性不同

## B. 视觉与体验

- [ ] 桌面 1366×768、1280×720（投影）、1024×768、小屏 390×844、窄屏 360×640 均有截图
- [ ] 开头一屏含标题、故事简介和开始按钮，文字不纵排、不重叠、页面不横向溢出
- [ ] CG 人物不被裁去关键部分，模态层可关闭，所有主要按钮可见
- [ ] 所有场景一幕一屏，漫画和剧情模式切换不丢失状态
- [ ] 页面文字无开发/模型内部指令泄漏，如「本版优化」「提示工程师」

## C. 声音

- [ ] 三种角色实际生成并试听，声线选择与用户标准一致
- [ ] 每句映射完整；漏音频次数为 0
- [ ] MP3 文件时长和解码检查通过；自动下一句只在音频结束后推进
- [ ] 字幕、暂停、跳幕、静音和自动播放同步，BGM 不盖过人声
- [ ] 断网后声音仍然一致；不得依赖运行设备的浏览器 TTS

## D. 业务与模型

- [ ] HUD 的客流、产量、价格、兼职人数和剧情一致
- [ ] 经营决策 A/B 逻辑有合理反馈，恢复/切幕不会错误沿用状态
- [ ] 模型页为独立导航场景，实时 `input` 更新曲线、交点、KPI、解释
- [ ] 最终通关页可打开、关闭、重玩，并回到模型；奖励不捏造用户成绩

## E. 技术

- [ ] `node --check app.js`；浏览器 JS 控制台无错误
- [ ] `python scripts/audit_courseware.py <源码目录> --require-voice --require-lab` 无问题
- [ ] `python scripts/pack_single_html.py <源码目录> <输出.html>` 完成
- [ ] 使用 Playwright/实际浏览器走通开始→第一幕→中间幕→模型→通关→重玩；断网重复关键步骤
- [ ] 验证 HTML 与 ZIP 存在、大小合理、可解压；`index.html` 在 ZIP 根目录
- [ ] 最终消息只声明**本轮亲自验证**的内容，留下清楚的未验证事项

## 推荐验证命令

```bash
python -m unittest discover -s tests -v
python scripts/audit_courseware.py /path/to/site --require-voice --require-lab
node --check /path/to/site/app.js
python scripts/pack_single_html.py /path/to/site /path/to/output.html
python scripts/browser_smoke.py /path/to/output.html --expected-scenes 10 --require-lab
```

注意：这里的 `scripts` 指本 Skill 目录里的脚本；在不同目录调用时写完整路径。脚本只支持 `data.js` 中 `const CONTENT=...;` 的站点结构，其他架构需要适配，不要以报错作为项目不合格的唯一判据。
